$('.navbar-toggler').click(function() {
    $('.navbar-collapse').slideToggle();
   });



